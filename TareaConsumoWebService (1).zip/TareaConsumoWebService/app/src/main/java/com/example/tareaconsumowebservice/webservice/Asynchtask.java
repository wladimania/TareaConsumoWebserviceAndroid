package com.example.tareaconsumowebservice.webservice;

import org.json.JSONException;

public interface Asynchtask {
    void processFinish(String result) throws JSONException;
}
